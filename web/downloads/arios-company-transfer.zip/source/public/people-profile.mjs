/** Optional work details saved in the same transaction as a person's account. */
import {latinDigits} from './identity.mjs';
import {normalizePartyCode} from './project-coding.mjs';
const plain=value=>value&&typeof value==='object'&&!Array.isArray(value);
function fail(message,code='INVALID_PERSON_DETAILS'){const error=new Error(message);error.status=400;error.code=code;throw error;}
function date(value){if(typeof value!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(value)||!Number.isFinite(Date.parse(`${value}T00:00:00Z`))||new Date(`${value}T00:00:00Z`).toISOString().slice(0,10)!==value)fail('تاریخ اجرای نرخ معتبر نیست.');return value;}
function time(value){if(typeof value!=='string'||!/^([01]\d|2[0-3]):[0-5]\d$/.test(value))fail('ساعت کاری معتبر نیست.');return value;}
export function assertPersonnelCodeAvailable(state,personId,value){
  if(!value)return '';
  const code=normalizePartyCode(value,'personnel');
  if((state?.users||[]).some(person=>{
    if(person.id===personId||!person.personnelCode)return false;
    try{return normalizePartyCode(person.personnelCode,'personnel')===code;}catch{return false;}
  })){
    const error=new Error('این کد پرسنلی قبلاً به فرد دیگری اختصاص یافته است؛ برای حساب حذف‌شده، همان حساب را بازیابی کنید.');
    error.status=409;error.code='DUPLICATE_PERSONNEL_CODE';throw error;
  }
  return code;
}
export function applyPersonProfile(person,payload={}){
  const next={};
  for(const [key,kind,customerOnly]of [['personnelCode','personnel',false],['customerCode','customer',true]]){
    if(payload[key]===undefined)continue;
    if(typeof payload[key]!=='string')fail(customerOnly?'کد مشتری معتبر نیست.':'کد پرسنلی معتبر نیست.');
    let code=latinDigits(payload[key].normalize('NFKC')).trim();const previous=latinDigits(String(person[key]??'').normalize('NFKC')).trim();
    // Existing identifiers are never rewritten by an unrelated profile edit.
    // A replacement follows the current numeric scheme and the person's group.
    if(code&&code!==previous){
      if(customerOnly&&person.role!=='customer'||!customerOnly&&person.role==='customer')fail(customerOnly?'کد پنج‌رقمی مشتری فقط برای مشتری ثبت می‌شود.':'کد شش‌رقمی پرسنلی فقط برای اعضای آریوس ثبت می‌شود.');
      try{code=normalizePartyCode(code,kind);}catch(error){fail(error.message);}
    }
    next[key]=code;
  }
  if(payload.personDetails===undefined){Object.assign(person,next);return person;}
  const details=payload.personDetails;
  if(!plain(details)||Object.keys(details).some(key=>!['availability','workStart','workEnd','hourlyRate','effectiveDate'].includes(key)))fail('جزئیات پروندهٔ همکار معتبر نیست.');
  if(person.role!=='worker'){if(Object.keys(details).length)fail('برنامهٔ کاری و نرخ فقط برای همکار اجرایی ثبت می‌شود.');Object.assign(person,next);return person;}
  if(details.availability!==undefined){if(!['','available','busy','leave'].includes(details.availability))fail('وضعیت کاری معتبر نیست.');next.availability=details.availability;}
  if(details.workStart!==undefined||details.workEnd!==undefined){
    const start=details.workStart||'',end=details.workEnd||'';
    if(typeof start!=='string'||typeof end!=='string'||Boolean(start)!==Boolean(end))fail('شروع و پایان ساعت کاری را با هم وارد کنید.');
    if(start&&(time(end)<=time(start)))fail('پایان ساعت کاری باید پس از شروع باشد.');
    Object.assign(next,{workStart:start,workEnd:end});
  }
  if(details.hourlyRate!==undefined||details.effectiveDate!==undefined){
    if(!Number.isSafeInteger(details.hourlyRate)||details.hourlyRate<0)fail('نرخ ساعتی باید عدد صحیح نامنفی باشد.');
    const effectiveDate=date(details.effectiveDate),rateHistory=structuredClone(person.rateHistory||[]),existing=rateHistory.find(entry=>entry.effectiveDate===effectiveDate);
    if(existing&&existing.hourlyRate!==details.hourlyRate){const error=new Error('برای این تاریخ نرخ دیگری ثبت شده است؛ تاریخ تازه‌ای انتخاب کنید.');error.status=409;error.code='DUPLICATE_RATE_DATE';throw error;}
    if(!existing)rateHistory.push({effectiveDate,hourlyRate:details.hourlyRate});
    rateHistory.sort((a,b)=>a.effectiveDate.localeCompare(b.effectiveDate));next.rateHistory=rateHistory;
    const today=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Tehran',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date()),applicable=rateHistory.filter(entry=>entry.effectiveDate<=today).at(-1);
    if(applicable)next.hourlyRate=applicable.hourlyRate;
  }
  Object.assign(person,next);return person;
}
