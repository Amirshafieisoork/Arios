import {renderReportProjectIdentity} from './project-admin.mjs';
import {hasPermission} from './permissions.mjs';
import {renderRecordActions,wireRecordActions} from './admin-workspace.mjs';
const list=value=>Array.isArray(value)?value:[];
const statusLabels={open:'انجام‌نشده',in_progress:'در حال انجام',done:'تکمیل‌شده'};
const staff=person=>person&&!person.deletedAt&&['manager','worker','warehouse','accountant'].includes(person.role);
/** Hourly reports require both report permission and a real execution assignment. */
export function canRecordProjectHours(state,project){
  const user=state?.user;
  if(!user||user.deletedAt||!project||project.archivedAt||project.canRecordWork===false||!hasPermission(user,'reports.submit',state))return false;
  if(user.role==='worker')return list(project.memberIds).includes(user.id);
  return user.role==='manager'&&list(project.memberIds).some(id=>list(state.users).some(person=>person.id===id&&person.role==='worker'&&!person.deletedAt));
}
export function hourlyReportMinutes({start,end,breakMinutes=0}={}){
  const valid=value=>typeof value==='string'&&/^([01]\d|2[0-3]):[0-5]\d$/.test(value);
  if(!valid(start)||!valid(end)||!Number.isInteger(breakMinutes)||breakMinutes<0)return null;
  const clock=value=>Number(value.slice(0,2))*60+Number(value.slice(3));
  const minutes=clock(end)-clock(start)-breakMinutes;
  return minutes>0?minutes:null;
}
const canPlan=state=>hasPermission(state.user,'tasks.manage',state);
const canUpdateTask=(state,task)=>task.assigneeId===state.user.id||hasPermission(state.user,task.sourceTicketId?'support.manage':'tasks.manage',state);
async function request(path,payload,{fetcher=fetch}={}) {
  const response=await fetcher('/api/'+path,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
  let data;try{data=await response.json();}catch{throw new Error('پاسخ سرور دریافت نشد؛ دوباره تلاش کنید.');}
  if(!response.ok)throw new Error(typeof data.error==='string'?data.error:'درخواست انجام نشد؛ دوباره تلاش کنید.');
  return data;
}
export async function downloadProjectFile(projectId,id,{fetcher=fetch,preview=false}={}) {
  const data=await request('project-files/download',{projectId,id,...(preview?{preview:true}:{})},{fetcher});
  let url;try{url=new URL(data.url);if(url.protocol!=='https:'||url.username||url.password||!url.hostname.endsWith('.supabase.co')||!url.pathname.startsWith('/storage/v1/object/sign/arios-project-files/'))throw Error();}catch{throw new Error('نشانی معتبر فایل دریافت نشد.');}
  return {url:url.href,expiresIn:data.expiresIn};
}
export async function uploadProjectFile(projectId,file,{draftId,clientVisible=false,fetcher=fetch}={}) {
  const mimeType=file.type||({jpg:'image/jpeg',jpeg:'image/jpeg',png:'image/png',webp:'image/webp',pdf:'application/pdf'}[file.name.split('.').at(-1)?.toLowerCase()]);
  if(!['image/jpeg','image/png','image/webp','application/pdf'].includes(mimeType)||!file.size||file.size>10*1024*1024)throw new Error('تصویر JPEG، PNG، WebP یا فایل PDF تا ۱۰ مگابایت انتخاب کنید.');
  const start=await request('project-files/upload-url',{projectId,fileName:file.name,mimeType,size:file.size,clientVisible,...(draftId?{draftId}:{})},{fetcher});
  let url;try{url=new URL(start.uploadUrl);if(url.protocol!=='https:'||url.username||url.password||!url.hostname.endsWith('.supabase.co')||!url.pathname.startsWith('/storage/v1/object/upload/sign/arios-project-files/'))throw Error();}catch{throw new Error('نشانی معتبر بارگذاری دریافت نشد.');}
  const uploaded=await fetcher(url.href,{method:'PUT',credentials:'omit',redirect:'error',headers:{'Content-Type':mimeType,'x-upsert':'false'},body:file});
  if(!uploaded.ok)throw new Error('بارگذاری کامل نشد؛ اینترنت را بررسی و فایل را دوباره انتخاب کنید.');
  return (await request('project-files/complete',{projectId,id:start.id},{fetcher})).file;
}
function fileButton(file,projectId,ctx,manage=false) {
  const download=`<button type="button" class="project-file" data-project-file="${ctx.e(file.id)}" data-file-project="${ctx.e(projectId)}">${file.mimeType?.startsWith('image/')?`<img class="project-file-thumb" data-project-thumb="${ctx.e(file.id)}" data-thumb-project="${ctx.e(projectId)}" alt="${ctx.e(file.name)}" hidden loading="lazy" referrerpolicy="no-referrer">`:''}<span class="project-file-icon">${ctx.icon(file.mimeType?.startsWith('image/')?'projects':'reports')}</span><strong>${ctx.e(file.name)}</strong><small>${ctx.n((file.size||0)/1024)} کیلوبایت · ${ctx.e(file.clientVisible?'قابل مشاهده برای مشتری':'داخلی تیم')}</small><span>دریافت فایل ${ctx.icon('download')}</span></button>`;
  if(!manage)return download;
  return `<article class="project-file-card">${download}<div class="actions project-file-controls">${file.archivedAt?`<button type="button" class="button secondary small" data-project-file-restore="${ctx.e(file.id)}">بازیابی فایل</button>`:`<button type="button" class="button secondary small" data-project-file-edit="${ctx.e(file.id)}">ویرایش</button><button type="button" class="button ghost small" data-project-file-archive="${ctx.e(file.id)}">حذف</button>`}</div></article>`;
}
export function tomorrowTehran(now=new Date()) {
  const parts=Object.fromEntries(new Intl.DateTimeFormat('en-US',{timeZone:'Asia/Tehran',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(now).filter(part=>part.type!=='literal').map(part=>[part.type,part.value]));
  return new Date(Date.UTC(Number(parts.year),Number(parts.month)-1,Number(parts.day)+1)).toISOString().slice(0,10);
}
export function assignedMissions(state,{projectId='',assigneeId=''}={}) {
  if(!staff(state.user))return [];
  const people=new Set(list(state.users).filter(staff).map(user=>user.id));
  return list(state.projects).filter(project=>!project.archivedAt&&(!projectId||project.id===projectId)).flatMap(project=>list(project.tasks).filter(task=>!task.archivedAt&&people.has(task.assigneeId)&&(list(project.memberIds).includes(task.assigneeId)||list(state.users).some(person=>person.id===task.assigneeId&&person.role==='manager'))&&(canPlan(state)||task.assigneeId===state.user.id)&&(!assigneeId||task.assigneeId===assigneeId)).map(task=>({...task,projectId:project.id,projectName:project.name}))).sort((a,b)=>(a.status==='done')-(b.status==='done')||String(a.dueDate||'9999').localeCompare(String(b.dueDate||'9999'))||String(a.createdAt||'').localeCompare(String(b.createdAt||'')));
}
export function openMissionComposer(state,ctx,{projectId,assigneeId,task}={}) {
  if(!canPlan(state))return ctx.toast('دسترسی تعریف و ویرایش مأموریت برای این حساب فعال نیست.');
  if(task?.sourceTicketId){ctx.go?.('support');return;}
  const active=new Map(list(state.users).filter(user=>user.role==='worker'&&!user.deletedAt).map(user=>[user.id,user]));
  const projects=list(state.projects).filter(project=>list(project.memberIds).some(id=>active.has(id))&&(!assigneeId||list(project.memberIds).includes(assigneeId)));
  if(!projects.length)return ctx.toast(assigneeId?'ابتدا این عضو را به یک پروژه تخصیص دهید.':'ابتدا یک پروژه و نیروی اجرایی آن را مشخص کنید.');
  const selected=projects.find(project=>project.id===(task?.projectId||projectId))||projects[0];
  const options=(project,value)=>list(project.memberIds).filter(id=>active.has(id)).map(id=>`<option value="${ctx.e(id)}" ${id===value?'selected':''}>${ctx.e(active.get(id).name)}</option>`).join('');
  ctx.modal({title:task?'ویرایش مأموریت کاری':'مأموریت کاری جدید',submitLabel:task?'ذخیرهٔ تغییر مأموریت':'ثبت مأموریت برای عضو',body:`<p class="notice">برای دستورهایی مثل «فردا به این پروژه برو»، عضو، روز انجام و توضیح کوتاه را ثبت کنید. یادآوری ساعت ۲۱ تهران به اتصال تلگرام عضو و فعال بودن سرویس نیاز دارد.</p><label class="field"><span>پروژه</span><select name="projectId" required>${projects.map(project=>`<option value="${ctx.e(project.id)}" ${project.id===selected.id?'selected':''}>${ctx.e(project.projectCode?project.projectCode+' · '+project.name:project.name)}</option>`).join('')}</select></label><label class="field"><span>عضو مسئول</span><select name="assigneeId" required>${options(selected,task?.assigneeId||assigneeId)}</select></label><label class="field"><span>عنوان مأموریت</span><input name="title" maxlength="240" required value="${ctx.e(task?.title||'')}" placeholder="مثلاً بازدید و اجرای پروژه"></label><label class="field"><span>روز انجام</span><input name="dueDate" type="date" required value="${ctx.e(task?.dueDate||tomorrowTehran())}"></label><label class="field"><span>دستور و جزئیات کار</span><textarea name="description" maxlength="2000" rows="4" placeholder="مثلاً فردا ساعت ۹ به محل پروژه برو و با سرپرست هماهنگ کن">${ctx.e(task?.description||'')}</textarea></label>`,onSubmit:data=>ctx.mutate(task?'task.update':'task.create',{projectId:task?selected.id:data.get('projectId'),title:data.get('title'),assigneeId:data.get('assigneeId'),dueDate:data.get('dueDate'),description:data.get('description'),...(task?{id:task.id,version:task.version}:{})})});
  const form=document.querySelector('#modal-form');
  if(task)form.querySelector('[name="projectId"]').disabled=true;
  form.querySelector('[name="projectId"]').addEventListener('change',event=>{const project=projects.find(row=>row.id===event.target.value);form.querySelector('[name="assigneeId"]').innerHTML=options(project,assigneeId);});
}
export function renderMemberMissions(state,ctx,projectId='') {
  if(!staff(state.user))return '';
  const tasks=assignedMissions(state,{projectId});
  return `<section class="card member-missions"><div class="card-head"><div><h2>${canPlan(state)?'مأموریت‌های اعضای تیم':'مأموریت‌های من'}</h2><p class="muted">${canPlan(state)?'دستورهای کاری، پروژه و روز انجام هر عضو':'وظایف تخصیص‌یافته به شما؛ وضعیت اجرا را همین‌جا به‌روز کنید'}</p></div>${canPlan(state)?'<button class="button primary" data-mission-create>+ مأموریت جدید</button>':''}</div>${tasks.map(task=>`<article class="project-task-row"><div><a class="text-link" href="#project/${ctx.e(task.projectId)}/tasks">${ctx.e(task.title)}</a><p>${ctx.e(task.projectName)} · ${ctx.e(state.users.find(user=>user.id===task.assigneeId)?.name||'عضو تیم')} · ${task.dueDate?ctx.e(ctx.date(task.dueDate)):'بدون تاریخ'}</p>${task.description?`<p class="mission-instructions">${ctx.e(task.description)}</p>`:''}</div>${canUpdateTask(state,task)?`<label class="field"><span class="sr-only">وضعیت ${ctx.e(task.title)}</span><select data-mission-status="${ctx.e(task.id)}" data-mission-project="${ctx.e(task.projectId)}">${Object.entries(statusLabels).map(([value,label])=>`<option value="${value}" ${task.status===value?'selected':''}>${label}</option>`).join('')}</select></label>`:`<span class="badge">${ctx.e(statusLabels[task.status]||'')}</span>`}${renderRecordActions(state,ctx,'tasks',task)}</article>`).join('')||'<p class="muted">هنوز مأموریتی تخصیص داده نشده است.</p>'}</section>`;
}
export function wireMemberMissions(state,ctx) {
  wireRecordActions(state,ctx);
  document.querySelectorAll('[data-mission-create]').forEach(button=>button.addEventListener('click',()=>openMissionComposer(state,ctx)));
  document.querySelectorAll('[data-member-mission]').forEach(button=>button.addEventListener('click',()=>openMissionComposer(state,ctx,{assigneeId:button.dataset.memberMission})));
  document.querySelectorAll('[data-mission-edit]').forEach(button=>button.addEventListener('click',()=>{const task=assignedMissions(state).find(row=>row.id===button.dataset.missionEdit&&row.projectId===button.dataset.missionProject);if(task)openMissionComposer(state,ctx,{task});}));
  document.querySelectorAll('[data-mission-status]').forEach(select=>select.addEventListener('change',async()=>{const task=assignedMissions(state).find(row=>row.id===select.dataset.missionStatus&&row.projectId===select.dataset.missionProject);if(!task)return;select.disabled=true;try{await ctx.mutate('task.update',{projectId:task.projectId,id:task.id,version:task.version,status:select.value});}catch(error){select.value=task.status;select.disabled=false;ctx.toast(error.message);}}));
}
export function renderProjectWorkspace(state,project,tab,ctx) {
  if(!project)return '';
  if(tab==='team')return `<section class="card"><div class="card-head"><h2>تیم اجرایی پروژه</h2><span class="muted">${ctx.n(list(project.memberIds).length)} عضو</span></div><div class="project-team-grid">${list(project.memberIds).map(id=>state.users.find(user=>user.id===id)).filter(Boolean).map(user=>`<article class="project-team-member"><span class="avatar">${ctx.e(user.name?.slice(0,1))}</span><div><strong>${ctx.e(user.name)}</strong><p>${ctx.e(user.skill||user.department||'نیروی اجرایی')}</p><small>${ctx.n(list(project.tasks).filter(task=>task.assigneeId===user.id&&task.status!=='done').length)} وظیفهٔ باز</small></div>${user.deletedAt?'<span class="badge gray">بایگانی‌شده</span>':''}</article>`).join('')||ctx.empty('هنوز نیرویی به این پروژه تخصیص داده نشده است.')}</div></section>`;
  if(tab==='files')return `<section class="card"><div class="card-head"><div><h2>فایل‌ها و تصاویر پروژه</h2><p class="muted">اسناد و تصاویر واقعی، با دسترسی محدود به پروژه</p></div>${hasPermission(state.user,'documents.upload',state)?'<button type="button" class="button primary" data-project-upload>افزودن فایل</button>':''}</div><div class="project-file-grid">${list(project.files).map(file=>fileButton(file,project.id,ctx,hasPermission(state.user,'documents.manage',state))).join('')||ctx.empty('هنوز فایل یا تصویری برای این پروژه بارگذاری نشده است.')}</div>${hasPermission(state.user,'documents.manage',state)?`<details class="project-file-archive"><summary>فایل‌های حذف‌شده (${ctx.n(list(project.archivedFiles).length)})</summary><p class="muted">فایل‌های حذف‌شده قابل بازیابی‌اند؛ مدارک گزارش‌های ثبت‌شده حفظ می‌شوند.</p><div class="project-file-grid">${list(project.archivedFiles).map(file=>fileButton(file,project.id,ctx,true)).join('')||ctx.empty('فایل حذف‌شده‌ای وجود ندارد.')}</div></details>`:''}</section>`;
  if(tab!=='tasks'||!staff(state.user))return '';
  const tasks=list(project.tasks).filter(task=>!task.archivedAt),members=list(project.memberIds).map(id=>state.users.find(user=>user.id===id));
  return `<section class="card"><div class="card-head"><div><h2>وظایف پروژه</h2><p class="muted">${ctx.n(tasks.filter(task=>task.status==='done').length)} از ${ctx.n(tasks.length)} وظیفه تکمیل شده</p></div>${canPlan(state)?'<button type="button" class="button primary" data-task-create>وظیفهٔ جدید +</button>':''}</div><div class="project-task-list">${tasks.map(task=>`<article class="project-task-row"><div><strong>${ctx.e(task.title)}</strong><p>${ctx.e(members.find(user=>user?.id===task.assigneeId)?.name||'بدون مسئول')} · ${task.dueDate?ctx.e(ctx.date(task.dueDate)):'بدون روز انجام'}</p>${task.description?`<p class="mission-instructions">${ctx.e(task.description)}</p>`:''}</div>${canUpdateTask(state,task)?`<label class="field"><span class="sr-only">وضعیت ${ctx.e(task.title)}</span><select data-task-status="${ctx.e(task.id)}">${Object.entries(statusLabels).map(([value,label])=>`<option value="${value}" ${task.status===value?'selected':''}>${label}</option>`).join('')}</select></label>`:`<span class="badge ${task.status==='done'?'green':'gold'}">${statusLabels[task.status]||''}</span>`}${renderRecordActions(state,ctx,'tasks',{...task,projectId:project.id})}</article>`).join('')||ctx.empty('اولین وظیفهٔ اجرایی پروژه را ثبت کنید.')}</div></section>`;
}
export function wireProjectWorkspace(state,project,tab,ctx) {
  if(!project)return;
  wireRecordActions(state,ctx);
  document.querySelector('[data-task-create]')?.addEventListener('click',()=>openMissionComposer(state,ctx,{projectId:project.id}));
  document.querySelectorAll('[data-task-status]').forEach(select=>select.addEventListener('change',async()=>{select.disabled=true;const task=list(project.tasks).find(task=>task.id===select.dataset.taskStatus);try{await ctx.mutate('task.update',{projectId:project.id,id:task.id,version:task.version,status:select.value});}catch(error){select.disabled=false;select.value=task.status;ctx.toast(error.message);}}));
  document.querySelector('[data-project-upload]')?.addEventListener('click',()=>{
    ctx.modal({title:'افزودن فایل پروژه',submitLabel:'بارگذاری و ثبت فایل',body:`<p class="muted">تصویر JPEG، PNG، WebP یا PDF تا ۱۰ مگابایت. فایل فقط در همین پروژه نگه‌داری می‌شود.</p><label class="field"><span>فایل</span><input type="file" name="file" required accept="image/jpeg,image/png,image/webp,application/pdf"></label>${hasPermission(state.user,'documents.manage',state)?'<label class="checkbox-label"><input type="checkbox" name="clientVisible">این فایل برای مشتری همین پروژه هم قابل مشاهده باشد</label>':'<p class="muted">این فایل فقط برای تیم اجرایی پروژه است.</p>'}`,onSubmit:async data=>{if(ctx.api.isStatic)throw new Error('بارگذاری فایل واقعی در نسخهٔ نمایشی فعال نیست.');await uploadProjectFile(project.id,data.get('file'),{clientVisible:data.has('clientVisible')});await ctx.refresh();ctx.toast('فایل پروژه ثبت شد.');}});
  });
  wireReportAttachments(ctx);
  wireProjectFileManagement(state,project,ctx);

}
export async function manageProjectFile(projectId,id,action,changes,{fetcher=fetch}={}) {
  if(!['update','archive','restore'].includes(action))throw new Error('عملیات فایل معتبر نیست.');
  return request('project-files/'+action,{projectId,id,...(action==='update'?{changes}:{})},{fetcher});
}
export function wireProjectFileManagement(state,project,ctx) {
  if(!hasPermission(state.user,'documents.manage',state))return;
  const all=[...list(project.files),...list(project.archivedFiles)];
  const submit=async(file,action,changes)=>{if(ctx.api.isStatic)throw new Error('مدیریت فایل واقعی در نسخهٔ نمایشی فعال نیست.');await manageProjectFile(project.id,file.id,action,changes);await ctx.refresh();ctx.toast(action==='archive'?'فایل از فهرست فعال حذف شد.':action==='restore'?'فایل بازیابی شد.':'اطلاعات فایل ذخیره شد.');};
  document.querySelectorAll('[data-project-file-edit]').forEach(button=>button.addEventListener('click',()=>{
    const file=all.find(row=>row.id===button.dataset.projectFileEdit);if(!file)return;
    ctx.modal({title:'ویرایش فایل پروژه',submitLabel:'ذخیرهٔ تغییرات',body:`<label class="field"><span>نام فایل، همراه با پسوند فعلی</span><input name="name" value="${ctx.e(file.name)}" required maxlength="180"></label><label class="checkbox-label"><input name="clientVisible" type="checkbox" ${file.clientVisible?'checked':''}>این فایل برای مشتری همین پروژه هم قابل مشاهده باشد</label>`,onSubmit:data=>submit(file,'update',{name:data.get('name'),clientVisible:data.has('clientVisible')})});
  }));
  for(const action of ['archive','restore'])document.querySelectorAll('[data-project-file-'+action+']').forEach(button=>button.addEventListener('click',()=>{
    const file=all.find(row=>row.id===button.dataset[action==='archive'?'projectFileArchive':'projectFileRestore']);if(!file)return;
    ctx.modal({title:action==='archive'?'حذف فایل از فهرست فعال':'بازیابی فایل',submitLabel:action==='archive'?'حذف فایل':'بازیابی فایل',body:`<p>${ctx.e(file.name)}</p><p class="notice">${action==='archive'?'فایل از فهرست فعال حذف می‌شود و بعداً قابل بازیابی است. مدارک گزارش‌های ثبت‌شده از بین نمی‌روند.':'فایل دوباره در فهرست پروژه، مطابق تنظیم قبلی دسترسی مشتری نمایش داده می‌شود.'}</p>`,onSubmit:()=>submit(file,action)});
  }));
}
export function renderReportAttachments(report,ctx) {
  const location=report.location;
  const gps=location?`<p class="report-gps">${ctx.icon('location')} موقعیت ثبت‌شده: <bdi>${ctx.e(Number(location.latitude).toFixed(5))}, ${ctx.e(Number(location.longitude).toFixed(5))}</bdi> · دقت حدود ${ctx.n(Math.round(location.accuracy))} متر</p>`:'';
  return `${gps}${list(report.photoIds).length?`<div class="report-attachment-actions">${report.photoIds.map((id,index)=>`<button type="button" class="button secondary report-photo-download" data-project-file="${ctx.e(id)}" data-file-project="${ctx.e(report.projectId)}"><img class="report-photo-thumb" data-project-thumb="${ctx.e(id)}" data-thumb-project="${ctx.e(report.projectId)}" alt="تصویر ${ctx.n(index+1)} گزارش" hidden referrerpolicy="no-referrer">تصویر ${ctx.n(index+1)} ${ctx.icon('download')}</button>`).join('')}</div>`:''}`;
}
export function wireReportAttachments(ctx) {
  const thumbnails=[...document.querySelectorAll('[data-project-thumb]')].filter(image=>!image.dataset.loading).slice(0,8);
  const load=async image=>{if(image.dataset.loading)return;image.dataset.loading='true';try{const result=await downloadProjectFile(image.dataset.thumbProject,image.dataset.projectThumb,{preview:true});if(!image.isConnected)return;image.src=result.url;image.hidden=false;image.addEventListener('error',()=>{image.hidden=true;},{once:true});}catch{image.hidden=true;}};
  if(thumbnails.length&&typeof IntersectionObserver==='function'){
    const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){observer.unobserve(entry.target);load(entry.target);}}),{rootMargin:'100px'});
    thumbnails.forEach(image=>{image.hidden=false;observer.observe(image);});setTimeout(()=>observer.disconnect(),90000);
  }else thumbnails.forEach(load);
  document.querySelectorAll('[data-project-file]').forEach(button=>{
    if(button.dataset.fileWired)return;button.dataset.fileWired='true';
    button.addEventListener('click',async()=>{button.disabled=true;try{const data=await downloadProjectFile(button.dataset.fileProject,button.dataset.projectFile);const anchor=document.createElement('a');anchor.href=data.url;anchor.target='_blank';anchor.rel='noopener noreferrer';anchor.click();}catch(error){ctx.toast(error.message);}finally{button.disabled=false;}});
  });
}
export function renderReportDrafts(state,ctx) {
  const drafts=list(state.reportDrafts);
  return drafts.length?`<section class="card report-drafts"><div class="card-head"><h2>پیش‌نویس‌های خصوصی من</h2><p class="muted">هنوز برای بررسی یا محاسبهٔ کارکرد ارسال نشده‌اند</p></div>${drafts.map(draft=>`<div class="project-task-row"><div><strong>${ctx.e(state.projects.find(project=>project.id===draft.projectId)?.name||'پروژه')}</strong><p>${ctx.e(draft.description?.slice(0,100)||'پیش‌نویس گزارش کار')} · ${ctx.e(ctx.date(draft.updatedAt))}</p></div><button type="button" class="button secondary" data-report-draft="${ctx.e(draft.id)}">ادامهٔ گزارش</button><button type="button" class="button ghost" data-delete-report-draft="${ctx.e(draft.id)}">حذف</button></div>`).join('')}</section>`:'';
}
export function wireReportDrafts(state,ctx) {
  document.querySelectorAll('[data-report-draft]').forEach(button=>button.addEventListener('click',()=>{const draft=list(state.reportDrafts).find(draft=>draft.id===button.dataset.reportDraft);if(draft)openReportComposer(state,ctx,draft.projectId,{draftId:draft.id});}));
  document.querySelectorAll('[data-delete-report-draft]').forEach(button=>button.addEventListener('click',async()=>{const draft=list(state.reportDrafts).find(draft=>draft.id===button.dataset.deleteReportDraft);if(!draft)return;button.disabled=true;try{await ctx.mutate('report.draft.delete',{id:draft.id,version:draft.version});}catch(error){button.disabled=false;ctx.toast(error.message);}}));
}
export function openReportComposer(state,ctx,projectId,options={}) {
  if(!hasPermission(state.user,'reports.submit',state)||!['manager','worker'].includes(state.user.role))return ctx.toast('ثبت گزارش برای این حساب فعال نیست.');
  const projects=list(state.projects).filter(project=>canRecordProjectHours(state,project));
  if(!projects.length)return ctx.toast('ابتدا یک پروژه و نیروی اجرایی برای ثبت گزارش مشخص کنید.');
  if(projectId&&!projects.some(project=>project.id===projectId))return ctx.toast('ثبت گزارش ساعتی برای این پروژه در دسترس شما نیست.');
  const projectLocked=Boolean(projectId)&&!options.report;
  let draft=list(state.reportDrafts).find(draft=>draft.id===options.draftId), report=options.report;
  const initial=report||draft||{};
  let selected=projects.some(project=>project.id===(initial.projectId||projectId))?(initial.projectId||projectId):projects[0].id;
  let location=initial.location||null,photoIds=[...list(initial.photoIds)],busy=false,pendingSubmission=null;const photoPreviews=new Map();
  const workerOptions=project=>list(project?.memberIds).map(id=>state.users.find(user=>user.id===id&&!user.deletedAt&&user.role==='worker')).filter(Boolean);
  const value=(name,fallback='')=>ctx.e(initial[name]??fallback);
  const body=`<p class="notice">ساعت شروع، پایان و استراحت را وارد کنید؛ کارکرد خالص همین پروژه محاسبه می‌شود. گزارش پس از ارسال، از مسئول پروژه تا مدیرعامل مرحله‌به‌مرحله بررسی می‌شود. پیش‌نویس فقط برای خودتان قابل مشاهده است.</p><div data-report-project-identity>${renderReportProjectIdentity({projectId:selected},state,ctx)}</div><div class="form-grid"><label class="field"><span>پروژه</span><select name="projectId" required ${projectLocked?'disabled':''}>${projects.map(project=>`<option value="${ctx.e(project.id)}" ${project.id===selected?'selected':''}>${ctx.e(project.projectCode?project.projectCode+' · '+project.name:project.name)}</option>`).join('')}</select></label><label class="field"><span>تاریخ فعالیت</span><input type="date" name="date" value="${value('date',ctx.today())}" required></label>${state.user.role==='manager'?`<label class="field full"><span>نیروی اجرایی پروژه</span><select name="workerId" required>${workerOptions(projects.find(project=>project.id===selected)).map(user=>`<option value="${ctx.e(user.id)}" ${user.id===initial.workerId?'selected':''}>${ctx.e(user.name)}</option>`).join('')}</select></label>`:''}<label class="field"><span>ساعت شروع</span><input type="time" name="start" value="${value('start','')}" required></label><label class="field"><span>ساعت پایان</span><input type="time" name="end" value="${value('end','')}" required></label><label class="field"><span>استراحت (دقیقه)</span><input type="number" name="breakMinutes" min="0" max="1439" value="${value('breakMinutes',0)}" required></label><p class="field full report-hourly-duration" data-report-duration aria-live="polite">با وارد کردن ساعت‌ها، کارکرد خالص نمایش داده می‌شود.</p><label class="field full"><span>شرح فعالیت</span><textarea name="description" rows="4" maxlength="4000" required>${value('description')}</textarea></label><label class="field full"><span>نتیجه و کار باقی‌مانده</span><textarea name="output" rows="3" maxlength="4000">${value('output')}</textarea></label></div><section class="report-composer-extras"><h3>موقعیت مکانی (اختیاری)</h3><p class="muted">فقط با انتخاب شما دریافت و در گزارش داخلی ذخیره می‌شود.</p><div class="actions"><button type="button" class="button secondary" data-report-gps>ثبت موقعیت فعلی</button><button type="button" class="button ghost" data-report-gps-clear ${location?'':'hidden'}>حذف موقعیت</button></div><p data-report-gps-state role="status"></p><h3>تصاویر گزارش</h3><p class="muted">حداکثر ۶ تصویر JPEG، PNG یا WebP؛ هر فایل تا ۱۰ مگابایت.</p><label class="field"><span>افزودن تصویر</span><input type="file" data-report-photo accept="image/jpeg,image/png,image/webp" multiple></label><div class="report-photo-list" data-report-photos></div><p data-report-upload-state role="status"></p>${!report?'<button type="button" class="button secondary" data-report-draft-save>ذخیرهٔ پیش‌نویس و ادامه در فرصت دیگر</button>':''}</section>`;
  let form;
  const fields=()=>{const data=new FormData(form);return {projectId:form.querySelector('[name="projectId"]').value,workerId:state.user.role==='worker'?state.user.id:form.querySelector('[name="workerId"]').value,date:data.get('date'),start:data.get('start'),end:data.get('end'),breakMinutes:Number(data.get('breakMinutes')||0),description:data.get('description'),output:data.get('output'),location,photoIds};};
  const save=async()=>{const result=await ctx.api.action('report.draft.save',{...fields(),...(draft?{id:draft.id,version:draft.version}:{})});draft=result.result;return draft;};
  ctx.modal({title:report?'اصلاح گزارش کار ساعتی':'ثبت گزارش کار ساعتی',submitLabel:'ارسال برای بررسی',body,onSubmit:async()=>{if(busy)throw new Error('تا تکمیل بارگذاری صبر کنید.');if(report)await ctx.mutate('report.update',{...fields(),id:report.id,version:report.version});else {if(!pendingSubmission){await save();pendingSubmission={...fields(),draftId:draft.id};}try{await ctx.mutate('report.create',pendingSubmission);}catch(error){if(Number.isInteger(error.status)&&error.status>=400&&error.status<500){pendingSubmission=null;}else{form.querySelectorAll('input,select,textarea,button[type="button"]').forEach(control=>control.disabled=true);throw new Error('نتیجهٔ ارسال هنوز مشخص نیست. برای بررسی و دریافت همان گزارش، دوباره «ارسال برای بررسی» را بزنید.');}throw error;}}}});
  form=document.querySelector('#modal-form');
  const gpsState=form.querySelector('[data-report-gps-state]'),photoNode=form.querySelector('[data-report-photos]'),uploadState=form.querySelector('[data-report-upload-state]');
  const drawGPS=()=>{gpsState.textContent=location?`${Number(location.latitude).toFixed(5)}, ${Number(location.longitude).toFixed(5)} · دقت حدود ${Math.round(location.accuracy).toLocaleString('fa-IR')} متر`:'موقعیت ثبت نشده است.';form.querySelector('[data-report-gps-clear]').hidden=!location;};
  const drawPhotos=()=>{photoNode.innerHTML=photoIds.map((id,index)=>`<span class="report-photo-chip"><img data-composer-preview="${ctx.e(id)}" class="report-photo-thumb" alt="تصویر ${ctx.n(index+1)} گزارش" hidden referrerpolicy="no-referrer">تصویر ${ctx.n(index+1)} <button type="button" data-remove-photo="${ctx.e(id)}" aria-label="حذف تصویر ${ctx.n(index+1)}">×</button></span>`).join('');photoNode.querySelectorAll('[data-remove-photo]').forEach(button=>button.onclick=()=>{if(busy)return;photoIds=photoIds.filter(id=>id!==button.dataset.removePhoto);drawPhotos();});photoNode.querySelectorAll('[data-composer-preview]').forEach(async image=>{const id=image.dataset.composerPreview;try{if(!photoPreviews.has(id))photoPreviews.set(id,downloadProjectFile(selected,id,{preview:true}));const result=await photoPreviews.get(id);if(image.isConnected){image.src=result.url;image.hidden=false;image.onerror=()=>{image.hidden=true;};}}catch{photoPreviews.delete(id);}});};
  drawGPS();drawPhotos();
  const duration=form.querySelector('[data-report-duration]');
  const drawDuration=()=>{const start=form.querySelector('[name="start"]').value,end=form.querySelector('[name="end"]').value,rest=form.querySelector('[name="breakMinutes"]').value;const minutes=hourlyReportMinutes({start,end,breakMinutes:Number(rest)});duration.textContent=!start||!end?'ساعت شروع و پایان فعالیت خود را وارد کنید.':minutes===null?'بازهٔ ساعت و زمان استراحت را بررسی کنید.':`کارکرد خالص: ${ctx.n(Math.floor(minutes/60))} ساعت و ${ctx.n(minutes%60)} دقیقه`;} ;
  for(const name of ['start','end','breakMinutes'])form.querySelector(`[name="${name}"]`).addEventListener('input',drawDuration);
  drawDuration();
  form.querySelector('[data-report-gps]').onclick=()=>{if(!navigator.geolocation){gpsState.textContent='مرورگر شما دریافت موقعیت را پشتیبانی نمی‌کند.';return;}gpsState.textContent='در حال دریافت موقعیت…';navigator.geolocation.getCurrentPosition(position=>{if(!form.isConnected)return;location={latitude:position.coords.latitude,longitude:position.coords.longitude,accuracy:position.coords.accuracy,capturedAt:new Date(position.timestamp).toISOString()};drawGPS();},()=>{if(form.isConnected)gpsState.textContent='موقعیت دریافت نشد؛ اجازهٔ مرورگر و روشن بودن مکان‌یابی را بررسی کنید.';},{enableHighAccuracy:true,timeout:15000,maximumAge:60000});};
  form.querySelector('[data-report-gps-clear]').onclick=()=>{location=null;drawGPS();};
  form.querySelector('[name="projectId"]').onchange=event=>{selected=event.target.value;const identity=form.querySelector('[data-report-project-identity]');if(identity)identity.innerHTML=renderReportProjectIdentity({projectId:selected},state,ctx);photoIds=[];location=null;drawPhotos();drawGPS();const worker=form.querySelector('[name="workerId"]');if(worker)worker.innerHTML=workerOptions(projects.find(project=>project.id===selected)).map(user=>`<option value="${ctx.e(user.id)}">${ctx.e(user.name)}</option>`).join('');};
  form.querySelector('[data-report-draft-save]')?.addEventListener('click',async event=>{if(busy)return;event.currentTarget.disabled=true;try{await save();await ctx.refresh();ctx.toast('پیش‌نویس خصوصی شما ذخیره شد.');}catch(error){event.currentTarget.disabled=false;uploadState.textContent=error.message;}});
  form.querySelector('[data-report-photo]').onchange=async event=>{if(busy)return;const files=[...event.target.files];if(files.length+photoIds.length>6){uploadState.textContent='حداکثر شش تصویر به هر گزارش اضافه کنید.';event.target.value='';return;}if(ctx.api.isStatic){uploadState.textContent='بارگذاری واقعی در نسخهٔ نمایشی فعال نیست.';return;}busy=true;event.target.disabled=true;const projectSelect=form.querySelector('[name="projectId"]'),workerSelect=form.querySelector('[name="workerId"]');projectSelect.disabled=true;if(workerSelect)workerSelect.disabled=true;const submit=form.querySelector('[type="submit"]');submit.disabled=true;try{if(!report)await save();for(let index=0;index<files.length;index++){uploadState.textContent=`بارگذاری تصویر ${(index+1).toLocaleString('fa-IR')} از ${files.length.toLocaleString('fa-IR')}…`;const file=await uploadProjectFile(selected,files[index],{...(draft?{draftId:draft.id}:{})});photoIds.push(file.id);drawPhotos();if(!report)await save();}uploadState.textContent='تصاویر بارگذاری و به پیش‌نویس پیوست شدند.';}catch(error){uploadState.textContent=error.message;}finally{busy=false;if(form.isConnected){projectSelect.disabled=projectLocked;if(workerSelect)workerSelect.disabled=false;event.target.disabled=false;event.target.value='';submit.disabled=false;}}};
}
