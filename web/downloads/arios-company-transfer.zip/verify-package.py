#!/usr/bin/env python3
"""Offline integrity check for an extracted ARIOS handover kit; no network or writes."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
manifest = json.loads((root / 'manifest.json').read_text(encoding='utf-8'))
for entry in manifest['files']:
    relative = Path(entry['path'])
    if relative.is_absolute() or '..' in relative.parts:
        raise SystemExit('Invalid manifest path')
    path = root / relative
    if not path.is_file() or path.is_symlink():
        raise SystemExit('Missing or unsafe file: ' + entry['path'])
    raw = path.read_bytes()
    if len(raw) != entry['bytes'] or hashlib.sha256(raw).hexdigest() != entry['sha256']:
        raise SystemExit('Integrity check failed: ' + entry['path'])
print('Verified', len(manifest['files']), 'files. Source commit:', manifest['sourceCommit'])
print('This kit does not contain live business data, Auth credentials or provider secrets.')
